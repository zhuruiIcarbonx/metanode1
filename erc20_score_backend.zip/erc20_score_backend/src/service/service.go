package service

import (
	"context"
	"log"
	"math/big"
	"strings"
	"time"

	"github.com/ethereum/go-ethereum"
	"github.com/ethereum/go-ethereum/accounts/abi"
	"github.com/ethereum/go-ethereum/accounts/abi/bind/v2"
	"github.com/ethereum/go-ethereum/common"
	"github.com/ethereum/go-ethereum/ethclient"
	"github.com/shopspring/decimal"
	"github.com/zeromicro/go-zero/core/threading"
	"github.com/zhuruiIcarbonx/erc20_score/erc20_score_backend/src/config"
	"github.com/zhuruiIcarbonx/erc20_score/erc20_score_backend/src/dao"
	"github.com/zhuruiIcarbonx/erc20_score/erc20_score_backend/src/logger"
	"google.golang.org/protobuf/internal/errors"
	"gorm.io/gorm"
)

const (
	EventIndexType                   = 6
	SleepInterval                    = 10 // in seconds
	SyncBlockPeriod                  = 10
	MultiChainMaxBlock               = 6
	LogMintTopic                     = "0xfc37f2ff950f95913eb7182357ba3c14df60ef354bc7d6ab1ba2815f249fffe6"
	LogBurnTopic                     = "0x0ac8bb53fac566d7afc05d8b4df11d7690a7b27bdc40b54e4060f9b21fb849bd"
	LogTranferTopic                  = "0xf629aecab94607bc43ce4aebd564bf6e61c7327226a797b002de724b9944b20e"
	ContractAbi                      = `["constructor(string,string)","error ERC20InsufficientAllowance(address,uint256,uint256)","error ERC20InsufficientBalance(address,uint256,uint256)","error ERC20InvalidApprover(address)","error ERC20InvalidReceiver(address)","error ERC20InvalidSender(address)","error ERC20InvalidSpender(address)","error OwnableInvalidOwner(address)","error OwnableUnauthorizedAccount(address)","event Approval(address indexed,address indexed,uint256)","event Burn(address indexed,uint256)","event Mint(address indexed,uint256)","event OwnershipTransferred(address indexed,address indexed)","event Transfer(address indexed,address indexed,uint256)","function allowance(address,address) view returns (uint256)","function approve(address,uint256) returns (bool)","function balanceOf(address) view returns (uint256)","function burn(address,uint256)","function decimals() view returns (uint8)","function mint(address,uint256)","function name() view returns (string)","function owner() view returns (address)","function renounceOwnership()","function symbol() view returns (string)","function totalSupply() view returns (uint256)","function transfer(address,uint256) returns (bool)","function transfer(address,address,uint256)","function transferFrom(address,address,uint256) returns (bool)","function transferOwnership(address)"]`
	HexPrefix                        = "0x"
	ZeroAddress                      = "0x0000000000000000000000000000000000000000"
	EventTypeMint                    = 0
	EventTypeTransfer                = 1
	EventTypeBurn                    = 2
	HourSeconds                      = 3600 * 1 // in seconds
	MaxCollectionFloorTimeDifference = 10       // in seconds

)

type Service struct {
	ctx        context.Context
	cfg        *config.Config
	db         *gorm.DB
	chainMap   map[string]*ethclient.Client
	addressMap map[string]string
}

type FilterQuery struct {
	BlockHash string   // used by eth_getLogs, return logs only from block with this hash
	FromBlock *big.Int // beginning of the queried range, nil means genesis block
	ToBlock   *big.Int // end of the range, nil means latest block
	Addresses []string // restricts matches to events created by specific contracts
	Topics    [][]string
}

func (s *Service) Start(chainIds []string) {

	//监听event，更新用户余额
	for _, v := range chainIds {
		client := s.chainMap[v]
		threading.GoSafe(s.SynEventLoop(v, client))
	}
	//计算用户分数
	for _, v := range chainIds {
		threading.GoSafe(s.SynCalculateScoreLoop(v))
	}

}

func (s *Service) SynEventLoop(chainId string, client *ethclient.Client) {

	chain := dao.ChainGetOne(s.db, chainId)

	syncFromBlock := uint64(Chain.SynFromBlockNum)
	lastSyncBlock := uint64(Chain.SynedBlockNum)
	if lastSyncBlock < syncFromBlock {
		lastSyncBlock = syncFromBlock
	}

	for {
		select {
		case <-s.ctx.Done():
			log.Printf("SynEventLoop stopped due to context cancellation! chaiId:" + chaiId)
			return
		default:
		}

		currentBlockNum, err := client.BlockNumber() // 以轮询的方式获取当前区块高度
		if err != nil {
			log.Printf("failed on get current block number", err)
			time.Sleep(SleepInterval * time.Second)
			continue
		}

		if lastSyncBlock > currentBlockNum-MultiChainMaxBlock { // 如果上次同步的区块高度大于当前区块高度，等待一段时间后再次轮询
			time.Sleep(SleepInterval * time.Second)
			continue
		}

		startBlock := lastSyncBlock
		endBlock := startBlock + SyncBlockPeriod
		if endBlock > currentBlockNum-MultiChainMaxBlock { // 如果结束区块高度大于当前区块高度，将结束区块高度设置为当前区块高度
			endBlock = currentBlockNum - MultiChainMaxBlock
		}

		query := FilterQuery{
			FromBlock: new(big.Int).SetUint64(startBlock),
			ToBlock:   new(big.Int).SetUint64(endBlock),
			Addresses: []string{chain.ContractAddress},
		}

		logs, err := s.FilterLogs(s.ctx, query, client) //同时获取多个（SyncBlockPeriod）区块的日志
		if err != nil {
			log.Printf("failed on get log", err)
			time.Sleep(SleepInterval * time.Second)
			continue
		}

		for _, log := range logs { // 遍历日志，根据不同的topic处理不同的事件
			ethLog := log.(ethereumTypes.Log)
			switch ethLog.Topics[0].String() {
			case LogeMintTopic:
				s.handleMintEvent(ethLog, chain)
			case LogBurnTopic:
				s.handleBurnEvent(ethLog, chain)
			case LogTransferTopic:
				s.handleTransferEvent(ethLog, chain)
			default:
			}
		}

		lastSyncBlock = endBlock + 1 // 更新最后同步的区块高度
		dao.ChainUpdateSynedBlockNum(s.db, chainId, lastSyncBlock)

		logger.Log.Printf("sync orderbook event ... start_block:%v, end_block:%v", startBlock, endBlock)

	}

}

func (s *Service) FilterLogs(ctx context.Context, q logTypes.FilterQuery, chainId string) ([]interface{}, error) {

	var addresses []common.Address
	for _, addr := range q.Addresses {
		addresses = append(addresses, common.HexToAddress(addr))
	}

	var topicsHash [][]common.Hash
	for _, topics := range q.Topics {
		var topicHash []common.Hash
		for _, topic := range topics {
			topicHash = append(topicHash, common.HexToHash(topic))
		}
		topicsHash = append(topicsHash, topicHash)
	}

	queryParam := ethereum.FilterQuery{
		FromBlock: q.FromBlock,
		ToBlock:   q.ToBlock,
		Addresses: addresses,
		Topics:    topicsHash,
	}

	client := s.clientMap[chainId]
	logs, err := client.FilterLogs(ctx, queryParam)
	if err != nil {
		return nil, errors.Wrap(err, "failed on get events")
	}

	var logEvents []interface{}
	for _, log := range logs {
		logEvents = append(logEvents, log)
	}

	return logEvents, nil
}

func (s *Service) handleMintEvent(log ethereumTypes.Log, chain *Chain) {

	var event struct {
		to    common.Address
		value *big.Int
	}
	parsedAbi, _ := abi.JSON(strings.NewReader(contractAbi)) // 通过ABI实例化
	err := parsedAbi.UnpackIntoInterface(&event, "Mint", log.Data)
	if err != nil {
		log.Printf("Error unpacking Mint event:", err)
		return
	}

	toAddress := common.BytesToAddress(log.Topics[0].Bytes())
	value := uint(new(big.Int).SetBytes(log.Topics[1].Bytes()).Uint64())

	client := s.clientMap[chain.chaiId]
	blockTime, err := client.BlockTimeByNumber(s.ctx, big.NewInt(int64(log.BlockNumber)))
	if err != nil {
		log.Printf("failed to get block time", err)
		return
	}
	tx := dao.Transaction{
		FromAccount: ZeroAddress,
		ToAccount:   toAddress,
		Amount:      value,
		Type:        EventTypeMint,
		BlockNumber: int64(log.BlockNumber),
		TxHash:      log.TxHash.String(),
		EventTime:   int64(blockTime),
		ChainId:     chain.chaiId,
	}

	dao.TransactionCreate(s.db, tx)

	//查询余额并录入
	tokenStr = s.addressMap[chain.chainId]
	tokenAddress := common.HexToAddress(tokenStr)
	instance, err := token.NewToken(tokenAddress, client)
	if err != nil {
		log.Fatal(err)
	}

	address := common.HexToAddress(toAddress)
	bal, err := instance.BalanceOf(&bind.CallOpts{}, address, log.BlockNumber)
	if err != nil {
		log.Fatal(err)
	}

	userBalance := dao.UserBalanceGetOne(s.db, toAddress)
	if userBalance.ID == 0 {

		userBalance := dao.UserBalance{UserAccount: toAddress, Balance: bal, ChainId: chain.chaiId, BlockTime: blockTime}
		dao.UserBalanceCreate(s.db, userBalance)

	} else {

		dao.UserBalanceUpdateBalance(s.db, chain.chaiId, toAddress, uint(bal))

	}

	userBalanceHis := dao.UserBalanceHis{UserAccount: toAddress, Balance: bal, ChainId: chain.chaiId, BlockTime: blockTime}
	dao.UserBalanceHisCreate(s.db, userBalanceHis)

}

func (s *Service) handleBurnEvent(log ethereumTypes.Log, chain *Chain) {

	var event struct {
		from  common.Address
		value *big.Int
	}
	parsedAbi, _ := abi.JSON(strings.NewReader(contractAbi)) // 通过ABI实例化
	err := parsedAbi.UnpackIntoInterface(&event, "Burn", log.Data)
	if err != nil {
		log.Printf("Error unpacking Burn event:", err)
		return
	}

	fromAddress := common.BytesToAddress(log.Topics[0].Bytes())
	value := uint(new(big.Int).SetBytes(log.Topics[1].Bytes()).Uint64())

	client := s.clientMap[chain.chaiId]
	blockTime, err := client.BlockTimeByNumber(s.ctx, big.NewInt(int64(log.BlockNumber)))
	if err != nil {
		log.Printf("failed to get block time", err)
		return
	}
	tx := dao.Transaction{
		FromAccount: fromAddress,
		ToAccount:   ZeroAddress,
		Amount:      value,
		Type:        EventTypeBurn,
		BlockNumber: int64(log.BlockNumber),
		TxHash:      log.TxHash.String(),
		EventTime:   int64(blockTime),
		ChainId:     chain.chaiId,
	}

	dao.TransactionCreate(s.db, tx)

	//查询余额并录入
	tokenStr = s.addressMap[chain.chainId]
	tokenAddress := common.HexToAddress(tokenStr)
	instance, err := token.NewToken(tokenAddress, client)
	if err != nil {
		log.Fatal(err)
	}

	address := common.HexToAddress(fromAddress)
	bal, err := instance.BalanceOf(&bind.CallOpts{}, address, log.BlockNumber)
	if err != nil {
		log.Fatal(err)
	}

	userBalance := dao.UserBalanceGetOne(s.db, fromAddress)
	if userBalance.ID == 0 {

		userBalance := dao.UserBalance{UserAccount: fromAddress, Balance: bal, ChainId: chain.chaiId, BlockTime: blockTime}
		dao.UserBalanceCreate(s.db, userBalance)

	} else {

		dao.UserBalanceUpdateBalance(s.db, chain.chaiId, fromAddress, uint(bal))

	}

	userBalanceHis := dao.UserBalanceHis{UserAccount: toAddress, Balance: bal, ChainId: chain.chaiId, BlockTime: blockTime}
	dao.UserBalanceHisCreate(s.db, userBalanceHis)

}

func (s *Service) handleTransferEvent(log ethereumTypes.Log, chain *Chain) {

	var event struct {
		from  common.Address
		to    common.Address
		value *big.Int
	}
	parsedAbi, _ := abi.JSON(strings.NewReader(contractAbi)) // 通过ABI实例化
	err := parsedAbi.UnpackIntoInterface(&event, "Transfer", log.Data)
	if err != nil {
		log.Printf("Error unpacking Transfer event:", err)
		return
	}

	fromAddress := common.BytesToAddress(log.Topics[0].Bytes())
	toAddress := common.BytesToAddress(log.Topics[0].Bytes())
	value := uint(new(big.Int).SetBytes(log.Topics[2].Bytes()).Uint64())

	client := s.clientMap[chain.chaiId]
	blockTime, err := client.BlockTimeByNumber(s.ctx, big.NewInt(int64(log.BlockNumber)))
	if err != nil {
		log.Printf("failed to get block time", err)
		return
	}
	tx := dao.Transaction{
		FromAccount: fromAddress,
		ToAccount:   toAddress,
		Amount:      value,
		Type:        EventTypeTransfer,
		BlockNumber: int64(log.BlockNumber),
		TxHash:      log.TxHash.String(),
		EventTime:   int64(blockTime),
		ChainId:     chain.chaiId,
	}

	dao.TransactionCreate(s.db, tx)

	//查询余额并录入
	tokenStr = s.addressMap[chain.chainId]
	tokenAddress := common.HexToAddress(tokenStr)
	instance, err := token.NewToken(tokenAddress, client)
	if err != nil {
		log.Fatal(err)
	}

	_fromAddress := common.HexToAddress(fromAddress)
	fromBal, err := instance.BalanceOf(&bind.CallOpts{}, _fromAddress, log.BlockNumber)
	if err != nil {
		log.Fatal(err)
	}

	fromUserBalance := dao.UserBalanceGetOne(s.db, fromAddress)
	if fromUserBalance.ID == 0 {

		_fromUserBalance := dao.UserBalance{UserAccount: fromAddress, Balance: fromBal, ChainId: chain.chaiId, BlockTime: blockTime}
		dao.UserBalanceCreate(s.db, _fromUserBalance)

	} else {

		dao.UserBalanceUpdateBalance(s.db, chain.chaiId, fromAddress, uint(fromBal))

	}
	userBalanceHis := dao.UserBalanceHis{UserAccount: fromAddress, Balance: bal, ChainId: chain.chaiId, BlockTime: blockTime}
	dao.UserBalanceHisCreate(s.db, userBalanceHis)

	_toAddress := common.HexToAddress(toAddress)
	toBal, err := instance.BalanceOf(&bind.CallOpts{}, _toAddress, log.BlockNumber)
	if err != nil {
		log.Fatal(err)
	}

	toUserBalance := dao.UserBalanceGetOne(s.db, toAddress)
	if toUserBalance.ID == 0 {

		_toUserBalance := dao.UserBalance{UserAccount: toAddress, Balance: toBal, ChainId: chain.chaiId, BlockTime: blockTime}
		dao.UserBalanceCreate(s.db, _toUserBalance)

	} else {

		dao.UserBalanceUpdateBalance(s.db, chain.chaiId, toAddress, uint(toBal))

	}
	userBalanceHis := dao.UserBalanceHis{UserAccount: toAddress, Balance: bal, ChainId: chain.chaiId, BlockTime: blockTime}
	dao.UserBalanceHisCreate(s.db, userBalanceHis)

}

func (s *Service) SynCalculateScoreLoop(chainIds []string) {

	timer := time.NewTicker(HourSeconds * time.Second)
	defer timer.Stop()

	for {
		select {
		case <-s.ctx.Done():
			log.Printf("SynCalculateScoreLoop stopped due to context cancellation")
			return
		case <-timer.C:
			if err := s.CalculateScore(chainIds); err != nil {
				log.Printf("failed on CalculateScore", err)
			}
		default:
		}
	}

}

// api调用
func (s *Service) ApiCalculateScore(chainId string, fromHour string, toHour string) { //fromHour:2025-01-01 12:00:00

	startHour, _ := time.ParseInLocation("2025-01-01 12:10:10", fromHour, time.Local) //startHour := util.stringToTime(fromHour)
	endHour, _ := time.ParseInLocation("2025-01-01 12:10:10", toHour, time.Local)     //endHour := util.stringToTime(toHour)
	for {
		if startHour > endHour {
			log.Printf("api to CalculateScore end ！ startHour:{},endHour:{}", fromHour, toHour)
			break
		}
		startTime := startHour
		DoCalculateScore(chainId, startTime)

		startHour := startHour.Add(1 * time.Hour)
	}

}

// 定时任务调用
func (s *Service) CalculateScore(chainId string) {

	now := time.Now()
	endTimeStr := now.Year() + "-" + now.Month() + "-" + now.Day() + " " + now.Hour() + ":00:00"
	endTime, _ := time.ParseInLocation("2025-01-01 12:10:10", endTimeStr, time.Local) //util.stringToTime(endTimeStr);
	startTime := endTime.Add(-1 * time.Hour)
	DoCalculateScore(chainId, startTime)

}

// 计算并更新score
func (s *Service) DoCalculateScore(chainId string, startTime time.Time) {

	endTime := startTime.Add(1 * time.Hour)
	startTimeStr := startTime.Format("2025-01-01 12:10:10")

	list := UserBalanceList(s.db, chaiId)
	for _, userBalance := range list {

		if userBalance.CreatTime > endTime { //用户如果还未创建，不就算得分
			log.Printf(" user not created at that time ！ user:{}", userBalance.UserAccount)
			continue
		}

		//计算score
		score := decimal.NewFromString("0")
		hisList := UserBalanceHisList(s.db, startTime, endTime)
		startRecord := UserBalanceHisGetOne(s.db, startTime)
		if len(hisList) == 0 && startRecord.ID == 0 {
			score = decimal.NewFromString("0")
		} else if len(hisList) == 0 && startRecord.ID != 0 {
			balanceStr := stringconv.FormUint(startRecord.Balance, 10)
			score = decimal.NewFromString(balanceStr).Mul(decimal.NewFromString("0.05"))
		} else if len(hisList) != 0 && startRecord.ID == 0 {

			for i := 0; i < len(hisList); i++ {

				bal1 := stringconv.FormUint(hisList[i].Balance, 10)
				time1 := hisList[i].BlockTime

				if i == len(hisList)-1 {
					time2 := endTime
				} else {
					time2 := hisList[i+1].BlockTime
				}
				duration := time2.Sub(time1)
				seconds := duration.Seconds()
				secondsStr := stringconv.FormUint(hisList[i].Balance, 10)
				score_i := decimal.NewFromString(bal1).Mul(decimal.NewFromString("0.05")).Mul(decimal.NewFromString(secondsStr))
				score = score.Add(score_i)
			}

			score = score.DivRound(decimal.NewFromString("60"), 2)

		} else {

			for i := 0; i < len(hisList); i++ {

				var bal1 string
				var time1, time2 time.Time

				if i == 0 {
					bal1 = stringconv.FormUint(startRecord.Balance, 10)
					time1 := startTime
					time2 := hisList[i+1].BlockTime
				} else if i == len(hisList)-1 {
					bal1 := stringconv.FormUint(hisList[i].Balance, 10)
					time1 := hisList[i].BlockTime
					time2 := endTime
				} else {
					bal1 := stringconv.FormUint(hisList[i].Balance, 10)
					time1 := hisList[i].BlockTime
					time2 := hisList[i+1].BlockTime
				}
				duration := time2.Sub(time1)
				seconds := duration.Seconds()
				secondsStr := stringconv.FormUint(hisList[i].Balance, 10)
				score_i := decimal.NewFromString(bal1).Mul(decimal.NewFromString("0.05")).Mul(decimal.NewFromString(secondsStr))
				score = score.Add(score_i)
			}
			score = score.DivRound(decimal.NewFromString("60"), 2)

		}

		userScore := dao.UserScoreGetOne(s.db, userBalance.ChainID, startTimeStr)
		if userScore.ID == 0 { //新增score
			userScore = dao.UserScore{
				CreatTime:   now,
				UpdatedTime: now,
				UserAccount: userBalance.UserAccount,
				Score:       score,
				ChainID:     userBalance.ChainID,
				ScoreTime:   startTimeStr,
			}
			dao.UserScoreCreate(s.db, userScore)

		} else { //更新
			dao.UserScoreUpdate(s.db, userBalance.ChainID, startTimeStr, score)
		}

		userScoreHis := dao.UserScoreHisGetOne(s.db, userBalance.ChainID, startTimeStr)
		if userScoreHis.ID == 0 { //新增score
			userScoreHis := dao.UserScoreHis{
				CreatTime:   now,
				UpdatedTime: now,
				UserAccount: userBalance.UserAccount,
				Score:       score,
				ChainID:     userBalance.ChainID,
				ScoreTime:   startTimeStr,
			}
			dao.UserScoreHisCreate(s.db, userScoreHis)

		} else { //覆盖已有数据
			dao.UserScoreHisUpdate(s.db, userBalance.ChainID, startTimeStr, score)
		}

	}

}

package util

import (
	"time"
)


func stringToTime(timeStr string) time.Time{

	timeTemplate1 := "2006-01-02 15:04:05"
	t, _ := time.ParseInLocation(timeTemplate1, timeStr, time.Local)
	return t

}